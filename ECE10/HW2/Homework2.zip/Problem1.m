clear;
clc;
close all;

tspan = [0 15];

% Define ICs

%y(1) = x;
%y(2) = xdot;
y0 = [-40; -36];

% Now solve using ode45
[t,y] = ode45(@particleODE, tspan, y0);

x = y(:,1);
xdot = y(:,2);
% Essentially extract the first column and second column components from y to be
% x and xdot

% First plot x(t)
subplot(2,1,1)
plot(t, x, 'g', 'LineWidth', 2)
grid on
xlabel('t (s)')
ylabel('x (ft)')
title('Position vs time')

subplot(2,1,2)
plot(t, xdot, 'r', 'LineWidth',2)
grid on
xlabel('t (s)')
ylabel('dx/dt (ft/s)')
title('Velocity vs time')

tc = interp1(x, t, 0);
fprintf('------Part B------\nApproximate tc where x(tc) = 0: %.3f s\n', tc);

% Now part b, using the tc we just solved for
y0_dist = [-40; -36; 0];

[t2, y2] = ode45(@particleODE_with_dist, [0 tc], y0_dist);

x2 = y2(:,1);
xdot2 = y2(:,2);
s2 = y2(:,3);

fprintf('Total distance traveled at t = tc: %.3f ft\n', s2(end));

function dydt = particleODE(t,y)
dydt = zeros(2,1);
dydt(1) = y(2);
dydt(2) = 6*t - 12;
end

function dydt = particleODE_with_dist(t,y)
dydt = zeros(3,1);
dydt(1) = y(2);
dydt(2) = 6*t - 12;
dydt(3) = abs(y(2));
end
